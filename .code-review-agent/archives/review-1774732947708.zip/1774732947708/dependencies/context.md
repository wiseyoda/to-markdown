# Review Context (dependencies)
## Repository
Path: /Users/ppatterson/dev/to-markdown
## Files to Review
The agent should explore the repository directly. Key source files:
- .mcp.json
- BACKLOG.md
- CHANGELOG.md
- CLAUDE.md
- INSTALL.md
- README.md
- REVIEW.md
- ROADMAP.md
- pyproject.toml
- src/to_markdown/__init__.py
- src/to_markdown/cli.py
- src/to_markdown/core/__init__.py
- src/to_markdown/core/background.py
- src/to_markdown/core/batch.py
- src/to_markdown/core/cli_helpers.py
- src/to_markdown/core/constants.py
- src/to_markdown/core/content_builder.py
- src/to_markdown/core/display.py
- src/to_markdown/core/extraction.py
- src/to_markdown/core/frontmatter.py
- src/to_markdown/core/pipeline.py
- src/to_markdown/core/sanitize.py
- src/to_markdown/core/setup.py
- src/to_markdown/core/tasks.py
- src/to_markdown/core/worker.py
- src/to_markdown/mcp/__init__.py
- src/to_markdown/mcp/__main__.py
- src/to_markdown/mcp/background_tools.py
- src/to_markdown/mcp/server.py
- src/to_markdown/mcp/tools.py
- src/to_markdown/smart/__init__.py
- src/to_markdown/smart/clean.py
- src/to_markdown/smart/images.py
- src/to_markdown/smart/llm.py
- src/to_markdown/smart/summary.py
- tests/__init__.py
- tests/conftest.py
- tests/test_batch.py
- tests/test_cli.py
- tests/test_constants_phase0125.py
- tests/test_extraction.py
- tests/test_formats/__init__.py
- tests/test_formats/conftest.py
- tests/test_formats/test_docx.py
- tests/test_formats/test_edge_cases.py
- tests/test_formats/test_html.py
- tests/test_formats/test_images.py
- tests/test_formats/test_pdf.py
- tests/test_formats/test_pptx.py
- tests/test_formats/test_xlsx.py
- ... and 13 more files

## REVIEW.md (Project-Specific Guidelines)

# REVIEW.md

## Always Check

- Security vulnerabilities (injection, XSS, auth bypass)
- Error handling and edge cases
- Input validation at system boundaries
- Resource cleanup (connections, file handles)
- Breaking changes to public APIs

## Style Preferences

- Follow python community conventions
- Consistent naming patterns
- Clear function signatures with types

## Skip

- Auto-generated files
- Vendored dependencies
- Test fixture data
